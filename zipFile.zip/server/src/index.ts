// Точка входа сервера. Поднимает Express, применяет миграции БД, создаёт демо-данные
// при первом запуске (если база пуста) и слушает 0.0.0.0:PORT (docs/PASSPORT.md, блок 3).
import path from "node:path";
import express from "express";
import session from "express-session";
import { env } from "./env";
import { runMigrations } from "./db/migrate";
import { seedDemoDataIfEmpty } from "./db/seed";
import { apiRouter } from "./routes";
import { errorHandler } from "./middleware/errorHandler";

async function main(): Promise<void> {
  await runMigrations();
  await seedDemoDataIfEmpty();

  const app = express();

  // За обратным прокси Replit секьюр-куки сессии работают только с доверием к прокси.
  app.set("trust proxy", 1);

  app.use(express.json({ limit: "5mb" }));
  app.use(
    session({
      secret: env.sessionSecret,
      resave: false,
      saveUninitialized: false,
      name: "revenue_return_cc_session",
      cookie: {
        httpOnly: true,
        secure: env.nodeEnv === "production",
        sameSite: "lax",
        maxAge: 12 * 60 * 60 * 1000, // 12 часов рабочей смены
      },
    }),
  );

  app.use("/api", apiRouter);

  // Собранный клиент (client/dist) отдаём как статику в продакшене (npm run build кладёт его сюда).
  const clientDist = path.join(__dirname, "..", "..", "client", "dist");
  app.use(express.static(clientDist));

  // SPA-роутинг: любой не-API GET-запрос отдаёт index.html, чтобы работали прямые ссылки
  // вида /cancellations/123 после перезагрузки страницы. В Express 5 маршрут-шаблон '*' для
  // этого больше не используется (path-to-regexp v8) — вместо него middleware без пути.
  app.use((req, res, next) => {
    if (req.method !== "GET" || req.path.startsWith("/api")) {
      next();
      return;
    }
    res.sendFile(path.join(clientDist, "index.html"), (error) => {
      if (error) next();
    });
  });

  app.use(errorHandler);

  app.listen(env.port, "0.0.0.0", () => {
    // eslint-disable-next-line no-console
    console.log(`Сервер «Возврат выручки контакт-центра» слушает http://0.0.0.0:${env.port}`);
  });
}

main().catch((error) => {
  // eslint-disable-next-line no-console
  console.error("Не удалось запустить сервер:", error);
  process.exit(1);
});
