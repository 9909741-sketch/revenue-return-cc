// Простой раннер SQL-миграций без внешних библиотек.
// Применяет все .sql-файлы из папки migrations по возрастанию имени,
// запоминает применённые версии в таблице schema_migrations.
import fs from "node:fs";
import path from "node:path";
import { pool } from "./pool";

// Файлы миграций лежат в server/migrations — вне src/dist, чтобы быть на месте
// и в режиме разработки (tsx, __dirname = server/src/db), и после сборки
// (tsc, __dirname = server/dist/db): в обоих случаях "../../migrations" ведёт в server/migrations.
const MIGRATIONS_DIR = path.join(__dirname, "..", "..", "migrations");

async function ensureMigrationsTable(): Promise<void> {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS schema_migrations (
      version text PRIMARY KEY,
      applied_at timestamptz NOT NULL DEFAULT now()
    )
  `);
}

async function getAppliedVersions(): Promise<Set<string>> {
  const result = await pool.query<{ version: string }>("SELECT version FROM schema_migrations");
  return new Set(result.rows.map((row) => row.version));
}

export async function runMigrations(): Promise<void> {
  await ensureMigrationsTable();
  const applied = await getAppliedVersions();

  const files = fs
    .readdirSync(MIGRATIONS_DIR)
    .filter((file) => file.endsWith(".sql"))
    .sort();

  for (const file of files) {
    if (applied.has(file)) {
      continue;
    }
    const sql = fs.readFileSync(path.join(MIGRATIONS_DIR, file), "utf-8");
    const client = await pool.connect();
    try {
      await client.query("BEGIN");
      await client.query(sql);
      await client.query("INSERT INTO schema_migrations (version) VALUES ($1)", [file]);
      await client.query("COMMIT");
      // eslint-disable-next-line no-console
      console.log(`Миграция применена: ${file}`);
    } catch (error) {
      await client.query("ROLLBACK");
      throw new Error(`Не удалось применить миграцию ${file}: ${(error as Error).message}`);
    } finally {
      client.release();
    }
  }
}
